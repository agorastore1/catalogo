'use strict';
(() => {
  const cfg = window.AGORA_CONFIG;
  const $ = s => document.querySelector(s);
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };
  const normalize = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const money = (cents, currency) => `${new Intl.NumberFormat('es', {minimumFractionDigits:2,maximumFractionDigits:2}).format(cents / 100)} ${currency}`;
  const safeImage = path => { try { const u = new URL(path, location.href); return ['http:', 'https:', 'file:'].includes(u.protocol) ? u.href : 'assets/placeholder.svg'; } catch { return 'assets/placeholder.svg'; } };
  const img = (src, alt) => { const n = el('img'); n.src = safeImage(src); n.alt = alt; n.loading = 'lazy'; n.addEventListener('error', () => { n.src = 'assets/placeholder.svg'; }, {once:true}); return n; };
  const wa = text => `https://wa.me/${cfg.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
  let products = [], cart = [], selected = '', search = '', toastTimer;
  const storageKey = 'agora-moda-cart-v1';
  const toast = message => { $('#toast').textContent = message; $('#toast').classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').classList.remove('show'), 4200); };
  function available(data) {
    if (!data || !Array.isArray(data.products)) throw Error('El catálogo no tiene el formato esperado.');
    const seen = new Set();
    return data.products.filter(p => {
      const valid = p && typeof p.id === 'string' && !seen.has(p.id) && typeof p.name === 'string' && typeof p.category === 'string' && Number.isSafeInteger(p.limit) && p.limit > 0 && p.prices && Object.entries(p.prices).length > 0 && Object.entries(p.prices).every(([c,v]) => ['CUP','USD'].includes(c) && Number.isSafeInteger(v) && v > 0);
      if (valid) seen.add(p.id); return valid;
    });
  }
  function reconcile() {
    const before = JSON.stringify(cart), ids = new Set();
    cart = cart.flatMap(item => {
      const p = products.find(p => p.id === item.id);
      if (!p || ids.has(item.id) || !Number.isInteger(item.qty) || item.qty < 1) return [];
      ids.add(item.id);
      const currency = Object.hasOwn(p.prices, item.currency) ? item.currency : Object.keys(p.prices)[0];
      return [{id:p.id, qty:Math.min(item.qty, p.limit), currency}];
    });
    return before !== JSON.stringify(cart);
  }
  function save() { try { localStorage.setItem(storageKey, JSON.stringify(cart)); } catch { toast('El navegador no permite guardar la bolsa. Se conservará durante esta visita.'); } }
  function update() { save(); $('#cart-count').textContent = cart.reduce((n,i) => n+i.qty,0); renderCart(); }
  function currencies(p, chosen, change, required = false) {
    const label = el('label','currency-label'); label.append(el('span','', 'Moneda de pago'));
    const select = el('select'); select.setAttribute('aria-label', `Moneda para ${p.name}`);
    if (required) { const option = el('option','', 'Elegir moneda'); option.value = ''; select.append(option); }
    for (const c of Object.keys(p.prices)) { const option=el('option','',c); option.value=c; select.append(option); }
    select.value=chosen; select.addEventListener('change',()=>change(select.value)); label.append(select); return label;
  }
  function renderCategories() {
    const counts = new Map(); products.forEach(p=>counts.set(p.category,(counts.get(p.category)||0)+1));
    if (selected && !counts.has(selected)) selected='';
    const nav=$('#categories'); nav.replaceChildren();
    for (const [cat,count] of [['', products.length], ...counts.entries()]) {
      const button=el('button','category',cat||'Todo'); button.type='button'; button.setAttribute('aria-pressed',String(selected===cat)); button.append(document.createTextNode(' '),el('span','',count));
      button.addEventListener('click',()=>{selected=cat;renderCategories();renderCatalog();}); nav.append(button);
    }
  }
  function renderCatalog() {
    const list=products.filter(p=>(!selected||p.category===selected)&&normalize(p.name).includes(normalize(search.trim())));
    $('#result-count').textContent=`${list.length} ${list.length===1?'pieza':'piezas'}`;
    $('#empty').hidden=!!list.length; $('#clear-search').hidden=!search; const root=$('#catalog'); root.replaceChildren();
    for(const category of [...new Set(list.map(p=>p.category))]) {
      const group=list.filter(p=>p.category===category), section=el('section'), title=el('h3','category-title',category);
      title.append(el('small','',`${group.length} PIEZAS`)); section.append(title); const grid=el('div','grid');
      for (const p of group) {
        const card=el('article','product'), photo=el('button','product-image'); photo.setAttribute('aria-label',`Ampliar imagen de ${p.name}`); photo.append(img(p.image,p.name),el('span','zoom-hint','→'));
        photo.addEventListener('click',()=>{$('#large-image').src=safeImage(p.image);$('#large-image').alt=p.name;$('#image-dialog').showModal();});
        const info=el('div','product-info'); info.append(el('p','product-category',p.category),el('h3','',p.name),el('p','product-description',p.description||''));
        const prices=el('div','prices'); Object.entries(p.prices).forEach(([c,value],i)=>{if(i)prices.append(el('span','or','o'));prices.append(el('span','price',money(value,c)));}); info.append(prices);
        const options=Object.keys(p.prices); let currency=options.length===1?options[0]:'';
        info.append(currencies(p,currency,c=>currency=c,options.length>1));
        const add=el('button','add','Agregar a la bolsa'); add.append(el('span','','+')); add.addEventListener('click',()=>{
          if(!currency){toast('Elige CUP o USD para este producto.');info.querySelector('select').focus();return;}
          const item=cart.find(i=>i.id===p.id);
          if(item&&item.qty>=p.limit){toast('Ya alcanzaste la cantidad disponible de este producto.');return;}
          if(item&&item.currency!==currency){toast('Este producto ya está en tu bolsa. Cambia allí su moneda antes de agregar más.');return;}
          if(item)item.qty++;else cart.push({id:p.id,qty:1,currency}); update();toast(`${p.name} se agregó a tu bolsa.`);
        });
        const contact=el('a','product-contact','Consultar por WhatsApp →');contact.href=wa(`Hola, me interesa ${p.name} de ${cfg.name}. ${Object.entries(p.prices).map(([c,v])=>money(v,c)).join(' o ')}. ¿Me puedes dar más información?`);contact.target='_blank';contact.rel='noopener noreferrer';info.append(add,contact);card.append(photo,info);grid.append(card);
      }
      section.append(grid);root.append(section);
    }
  }
  function totals(){const result={CUP:0,USD:0};for(const i of cart){const p=products.find(p=>p.id===i.id);result[i.currency]+=p.prices[i.currency]*i.qty;}return result;}
  function renderCart(){
    const root=$('#cart-items');root.replaceChildren();$('#cart-bottom').hidden=!cart.length;
    if(!cart.length){root.append(el('p','empty','Tu bolsa está esperando tus favoritos.'));return;}
    for(const item of cart){
      const p=products.find(p=>p.id===item.id),row=el('article','cart-item'),body=el('div'); row.append(img(p.image,p.name));body.append(el('h3','',p.name),el('div','',money(p.prices[item.currency]*item.qty,item.currency)));
      body.append(currencies(p,item.currency,c=>{item.currency=c;update();}));
      const qty=el('div','quantity'),minus=el('button','','−'),plus=el('button','','+'),count=el('output','',item.qty),remove=el('button','remove','Quitar');
      minus.setAttribute('aria-label',`Reducir cantidad de ${p.name}`);plus.setAttribute('aria-label',`Aumentar cantidad de ${p.name}`);count.setAttribute('aria-label',`Cantidad de ${p.name}`);minus.disabled=item.qty<=1;plus.disabled=item.qty>=p.limit;
      minus.onclick=()=>{if(item.qty>1)item.qty--;update();};plus.onclick=()=>{if(item.qty<p.limit)item.qty++;update();};remove.onclick=()=>{cart=cart.filter(i=>i.id!==item.id);update();};qty.append(minus,count,plus,remove);body.append(qty);row.append(body);root.append(row);
    }
    const t=totals();$('#total-cup').textContent=money(t.CUP,'CUP');$('#total-usd').textContent=money(t.USD,'USD');$('#order-link')?.remove();
  }
  async function refresh(){
    if(location.protocol==='file:')return;
    const response=await fetch('catalogo.json',{cache:'no-store'});if(!response.ok)throw Error('No se pudo actualizar el catálogo.');
    products=available(await response.json());
  }
  async function checkout(){
    const button=$('#checkout');button.disabled=true;
    try {
      const oldPrices=JSON.stringify(cart.map(i=>products.find(p=>p.id===i.id)?.prices));await refresh();
      const changed=reconcile();update();renderCategories();renderCatalog();
      const newPrices=JSON.stringify(cart.map(i=>products.find(p=>p.id===i.id)?.prices));
      if(changed||oldPrices!==newPrices){toast('Cambió la disponibilidad o el precio. Revisa tu bolsa y confirma de nuevo.');return;}
      if(!cart.length)return;
      const lines=[`Hola, quiero hacer este pedido de ${cfg.name}:`,''];
      for(const i of cart){const p=products.find(p=>p.id===i.id);lines.push(`• ${p.name} — ${i.qty} × ${money(p.prices[i.currency],i.currency)} = ${money(p.prices[i.currency]*i.qty,i.currency)}`);}
      const t=totals();lines.push('',`Total CUP: ${money(t.CUP,'CUP')}`,`Total USD: ${money(t.USD,'USD')}`,'','Cada producto se paga en la moneda elegida. Sujeto a confirmación de disponibilidad.');
      const url=wa(lines.join('\n')); const link=el('a','secondary','Abrir el pedido en WhatsApp →');link.id='order-link';link.href=url;link.target='_blank';link.rel='noopener noreferrer';$('#cart-bottom').append(link);
      window.open(url,'_blank','noopener,noreferrer');
      toast('Pedido preparado. La bolsa se conserva hasta que decidas quitar los productos.');
    } catch {toast('No se pudo comprobar el catálogo. Revisa tu conexión e inténtalo de nuevo.');} finally {button.disabled=false;}
  }
  function close(dialog){dialog.close();}
  async function init(){
    // Keep the sticky search below the header, including enlarged text.
    const headerObserver = new ResizeObserver(() => {
      document.documentElement.style.setProperty('--header-height', `${Math.ceil($('.header').getBoundingClientRect().height)}px`);
    });
    headerObserver.observe($('.header'));
    document.title=`${cfg.name} · Catálogo`;document.querySelectorAll('[data-brand]').forEach(n=>n.textContent=cfg.name);
    $('#logo').src=safeImage(cfg.logo);$('#logo').alt=`Logo ${cfg.name}`;$('#header-image').src=safeImage(cfg.headerImage);
    document.documentElement.style.setProperty('--pattern',`url("${safeImage(cfg.backgroundImage)}")`);document.documentElement.style.setProperty('--accent',cfg.accent);document.documentElement.style.setProperty('--background',cfg.background);
    $('#eyebrow').textContent=cfg.eyebrow;$('#headline').textContent=cfg.headline;$('#description').textContent=cfg.description;$('#demo-banner').hidden=!cfg.demo;
    document.querySelectorAll('[data-contact]').forEach(n=>n.href=wa(`Hola, quiero información sobre ${cfg.name}.`));
    try{products=available(window.AGORA_DATA);await refresh();}catch{if(!products.length){$('#catalog').textContent='No se pudo cargar el catálogo. Revisa los archivos de datos e inténtalo de nuevo.';return;}toast('Mostrando la última copia del catálogo. No se pudo actualizar.');}
    try{const stored=JSON.parse(localStorage.getItem(storageKey)||'[]');cart=Array.isArray(stored)?stored.filter(i=>i&&typeof i==='object'):[];}catch{cart=[];}
    if(reconcile())toast('Tu bolsa se ajustó a la disponibilidad actual.');update();renderCategories();renderCatalog();
    $('#search').addEventListener('input',e=>{search=e.target.value;renderCatalog();});
    $('#clear-search').onclick=()=>{search='';$('#search').value='';renderCatalog();$('#search').focus();};
    $('#reset-filters').onclick=()=>{search='';selected='';$('#search').value='';renderCategories();renderCatalog();};
    $('#open-cart').onclick=()=>$('#cart-dialog').showModal();$('#close-cart').onclick=()=>close($('#cart-dialog'));$('#close-image').onclick=()=>close($('#image-dialog'));$('#checkout').onclick=checkout;
    for(const selector of ['#cart-dialog','#image-dialog']){$(selector).addEventListener('click',e=>{if(e.target===$(selector)){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close(e.target);}});}
    window.addEventListener('storage',e=>{if(e.key!==storageKey)return;try{const data=JSON.parse(e.newValue||'[]');cart=Array.isArray(data)?data.filter(i=>i&&typeof i==='object'):[];reconcile();$('#cart-count').textContent=cart.reduce((s,i)=>s+i.qty,0);renderCart();}catch{}});
  }
  init();
})();
