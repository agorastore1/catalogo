window.AGORA_DATA = {
  "version": 1,
  "products": [
    {
      "id": "8fb5c3368e3c35b1450c9db4",
      "name": "Vestido Atenea",
      "description": "Silueta ligera y un azul que invita a salir. Tallas M y L.",
      "category": "Vestidos",
      "prices": {
        "CUP": 270000,
        "USD": 500
      },
      "limit": 4,
      "image": "assets/products/vestido.jpeg"
    },
    {
      "id": "7fe50b38d404e7fd46c71bab",
      "name": "Cadena Aura",
      "description": "Un detalle dorado para acompañar cada día.",
      "category": "Joyería",
      "prices": {
        "CUP": 162000,
        "USD": 300
      },
      "limit": 3,
      "image": "assets/products/cadena.jpeg"
    },
    {
      "id": "05529daf8be7d38b658d20c1",
      "name": "Bolso Oliva",
      "description": "Un toque de color con espacio para tus esenciales.",
      "category": "Accesorios",
      "prices": {
        "CUP": 432000,
        "USD": 800
      },
      "limit": 5,
      "image": "assets/products/bolso.webp"
    },
    {
      "id": "61173300f99dee5958d5728c",
      "name": "Tenis Calíope",
      "description": "Comodidad para recorrer la ciudad. Talla 38.",
      "category": "Calzado",
      "prices": {
        "CUP": 350000
      },
      "limit": 2,
      "image": "assets/products/tenis.webp"
    },
    {
      "id": "0a509da03f3655988acdee4f",
      "name": "Camisa Ícaro",
      "description": "Mezclilla de manga larga. Una pieza versátil.",
      "category": "Caballeros",
      "prices": {
        "USD": 1200
      },
      "limit": 6,
      "image": "assets/products/camisa.jpeg"
    },
    {
      "id": "b2fb7cefc10bec0984c08144",
      "name": "Vestido Pequeña Musa",
      "description": "Flores para los días de juego. Talla 4–5.",
      "category": "Infantil",
      "prices": {
        "CUP": 120000
      },
      "limit": 7,
      "image": "assets/products/infantil.jpeg"
    },
    {
      "id": "7f7ee0871935b7a3f2fe51aa",
      "name": "Vestido Egeo",
      "description": "",
      "category": "Vestidos",
      "prices": {
        "CUP": 324000,
        "USD": 600
      },
      "limit": 3,
      "image": "assets/products/vestido.jpeg"
    },
    {
      "id": "da8c7a68de1ce9d63eba08ed",
      "name": "Collar Helios",
      "description": "Acabado dorado y líneas delicadas.",
      "category": "Joyería",
      "prices": {
        "CUP": 216000,
        "USD": 400
      },
      "limit": 2,
      "image": "assets/products/cadena.jpeg"
    },
    {
      "id": "347539d7f623c4d0b211f3cb",
      "name": "Bolso de paseo",
      "description": "Ligero, práctico y lleno de personalidad.",
      "category": "Accesorios",
      "prices": {
        "CUP": 270000,
        "USD": 500
      },
      "limit": 4,
      "image": "assets/products/bolso.webp"
    }
  ]
};
