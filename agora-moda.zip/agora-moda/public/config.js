/* Personalización: imágenes locales relativas a index.html. */
window.AGORA_CONFIG = {
  name: 'Àgora Moda',
  whatsapp: '5358113140',
  logo: 'assets/logo.svg',
  headerImage: 'assets/cabecera.svg',
  backgroundImage: 'assets/greca.svg',
  eyebrow: 'UNA SELECCIÓN CON CARÁCTER',
  headline: 'El arte de vestir\ncon elegancia.',
  description: 'Piezas que hablan de ti. Descubre tu próximo favorito y prepara tu pedido con atención personal por WhatsApp.',
  demo: true, // false cuando reemplaces los productos de demostración
  accent: '#916b34',
  background: '#f8f5ef'
};
