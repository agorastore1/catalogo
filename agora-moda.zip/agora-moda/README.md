# Àgora Moda

Catálogo web adaptable a móviles, basado en Excel/CSV y sin dependencias para ejecutar o actualizar. Colores marfil, verde profundo y oro con trama griega local. Todos los productos incluidos son **ejemplos**: no representan ofertas reales.

## Estado de la entrega

- Incluye nueve productos visibles en seis categorías y dos filas agotadas de ejemplo.
- Las fotos de ejemplo proceden del repositorio del usuario `agorastore1/sales`.
- **Logo y cabecera provisionales.** Las dos imágenes mostradas en el chat no estaban disponibles como archivos en el entorno de desarrollo. El ZIP incluye sustitutos explícitos, no copias de esos originales. Para incorporar los originales, cópialos a `public/assets/logo.png` y `public/assets/cabecera.png` y cambia sus rutas en `public/config.js`.
- No se ha publicado el sitio ni enviado pedidos. No hay gestión automática de inventario.
- Validación: 7 pruebas de datos y prueba funcional HTTP en Chromium. La apertura directa `file://` no pudo validarse en este entorno porque el navegador administrado la bloquea; utiliza el servidor local para el flujo verificado.

## Revisión para móvil

Esta versión prioriza la lectura en teléfono: fichas de una columna hasta 650 px, nombres de 24 px, descripciones y controles de 16 px o más, precios de 21 px y botones con al menos 44 px de altura. Se ha aumentado el contraste del texto secundario y las fichas tienen fondo claro uniforme. La cabecera con la bolsa y la búsqueda con categorías permanecen accesibles al desplazarse. El sitio permite ampliar el texto; los campos de 16 px evitan el zoom automático de enfoque habitual en iOS. No depende de fuentes descargadas.

El logo y la imagen de cabecera siguen pendientes de recibir como archivos originales. No se han sustituido por reproducciones del contenido del chat.

## Empezar

1. Descomprime el ZIP conservando las carpetas.
2. Abre `public/index.html` en un navegador moderno: el catálogo ya está generado y funciona sin instalar herramientas.
3. Para trabajar con una dirección local estable y persistencia predecible de la bolsa, instala Python 3.10 o superior desde python.org (en Windows marca «Add Python to PATH»). Abre `VER_CATALOGO.bat` o ejecuta desde la carpeta del proyecto:

   ```sh
   python3 tools/serve.py
   ```

   En Windows puedes usar `python` en lugar de `python3`. El navegador se abre automáticamente. Mantén la terminal abierta y usa Ctrl+C para detener el servidor. El puerto predeterminado es 8000; puedes elegir otro con `--port 8001`. Si no quieres abrir el navegador, añade `--no-browser`.

El modo de archivo (`file://`) usa la copia incluida en `catalogo.js`. En ese modo la persistencia depende del navegador y de la ruta del archivo. Servir el sitio por HTTP/HTTPS es lo recomendado para uso habitual. No hay npm, bundler, backend, base de datos, fuentes remotas ni bibliotecas de interfaz.

## Actualizar desde Excel — opción recomendada

1. Edita `datos/productos.xlsx`, hoja **Productos**. La hoja **Instrucciones** contiene una guía resumida.
2. Conserva los encabezados exactos y el nombre de la hoja. Añade filas, cambia datos y guarda/cierra Excel.
3. Ejecuta `ACTUALIZAR_EXCEL.bat` o:

   ```sh
   python3 tools/build.py datos/productos.xlsx
   ```

4. El comando actualiza `datos/productos.csv`, `public/catalogo.json` y `public/catalogo.js`.
5. Recarga el navegador. Si el sitio está publicado, vuelve a subir la carpeta `public/` actualizada.

La lectura de Excel usa exclusivamente la biblioteca estándar de Python. No necesitas instalar openpyxl ni Excel en el servidor. No se admiten fórmulas en la hoja Productos: pega sus resultados como valores. No uses celdas combinadas. Los códigos con ceros iniciales deben ser texto.

## Actualizar desde CSV — alternativa

Exporta únicamente la hoja **Productos** con «CSV UTF-8». Sustituye `datos/productos.csv` y ejecuta `ACTUALIZAR_CSV.bat` o:

```sh
python3 tools/build.py datos/productos.csv
```

Se admiten separadores coma o punto y coma, BOM UTF-8, comillas y saltos de línea en campos correctamente entrecomillados. Usa hasta dos decimales, punto o coma decimal y **ningún separador de miles**. Excel pone las comillas necesarias al exportar. CSV → catálogo no actualiza el Excel: elige una fuente principal para evitar sobrescribir cambios con una hoja antigua. El XLSX sí regenera el CSV.

Si la validación falla, el comando muestra la fila y no sustituye el catálogo publicado. Corrige el dato y vuelve a ejecutar. Un catálogo sin productos disponibles es válido.

## Columnas

| Columna | Uso | Visible en la página |
|---|---|---|
| `cod` | Código único, obligatorio y estable; nunca reutilizar para otro producto | No |
| `prod` | Nombre del producto, obligatorio | Sí |
| `inv` | Unidades enteras, de 0 a 1.000.000; cero oculta el producto | No |
| `descripc` | Descripción opcional | Sí, si existe |
| `categ` | Categoría obligatoria | Sí |
| `costocup` | Coste interno en CUP | No |
| `preciocup` | Precio de venta en CUP | Si es mayor que cero |
| `costousd` | Coste interno en USD | No |
| `preciousd` | Precio de venta en USD | Si es mayor que cero |
| `img` | Ruta local o URL HTTP/HTTPS de la imagen | Solo la imagen |

Un precio vacío o cero significa que esa moneda no se ofrece. Un producto con existencias debe tener al menos un precio positivo. Los negativos, importes con más de dos decimales, códigos repetidos e imágenes locales inexistentes se rechazan. Los costes se conservan en Excel/CSV y no se incluyen en los archivos públicos. Los nombres de categoría deben escribirse de forma consistente: `Joyería` y `joyería` serían categorías diferentes.

Las categorías se calculan a partir de los productos con existencias. Si no tienen productos visibles, desaparecen. La búsqueda combina el filtro de categoría y el nombre del producto, sin distinguir mayúsculas ni tildes.

## Monedas, bolsa y pedidos

- Si hay CUP y USD, son **precios alternativos**. El visitante debe elegir una moneda antes de agregar el producto.
- Si solo hay un precio, esa moneda se selecciona automáticamente.
- Cada producto tiene una única línea y moneda en la bolsa; puede cambiarse desde ella. No se permite agregar otra moneda del mismo producto sin cambiar primero la elección de la bolsa.
- El máximo de cantidad es `inv`, contando todo lo agregado para ese producto.
- Los cálculos usan centavos enteros para evitar errores de redondeo.
- Los totales CUP y USD suman únicamente las líneas elegidas en cada moneda. No son equivalentes ni se aplica una tasa de cambio.
- La bolsa se guarda en `localStorage` con la clave `agora-moda-cart-v1`, en ese navegador y origen. Se sincroniza entre pestañas. No se guarda en una cuenta ni en un servidor.
- En modo HTTP, al confirmar se vuelve a leer el catálogo publicado. Si cambiaron cantidades, productos o precios, se ajusta la bolsa y se pide confirmarla de nuevo. Si la consulta falla, no se prepara un pedido desactualizado.
- WhatsApp abre `https://wa.me/5358113140` con nombres, cantidades, precios unitarios, subtotales y totales. No incluye costes ni códigos.
- El usuario debe revisar y enviar el mensaje en WhatsApp. El catálogo no puede confirmar que se envió, así que **no vacía la bolsa automáticamente**. Si se bloquea la ventana emergente, aparece un enlace para abrir el pedido.
- Enviar el pedido no reserva ni descuenta existencias. El vendedor confirma manualmente. Dos compradores pueden solicitar la última unidad al mismo tiempo.

## Personalización

Edita `public/config.js`:

| Propiedad | Qué cambia |
|---|---|
| `name` | Nombre del negocio, marca y mensajes |
| `whatsapp` | Número con código de país, solo dígitos: `5358113140` |
| `logo` | Ruta del logo, por ejemplo `assets/logo.png` |
| `headerImage` | Imagen de cabecera, por ejemplo `assets/cabecera.jpg` |
| `backgroundImage` | Trama o fondo local, por defecto `assets/greca.svg` |
| `eyebrow`, `headline`, `description` | Textos de portada; `\n` crea un salto en el título |
| `accent`, `background` | Colores CSS |
| `demo` | `false` para quitar el aviso una vez sustituidos los datos de prueba |

Las imágenes viajan dentro de `public/assets/`. Puedes usar PNG, JPG, WebP o SVG. La cabecera se adapta con `object-fit: cover`; cambia `object-position` en `styles.css` para ajustar el encuadre. Para cambiar la trama por una fotografía ajusta también `background-size` y `background-attachment` de `body`. Cambia el favicon y la descripción SEO en `public/index.html` si cambias la marca. El texto pequeño superpuesto a la cabecera y el pie de página también se editan allí.

Para fotos de productos, copia el archivo a `public/assets/products/` y pon esa ruta en `img`. La ruta es relativa a `public/index.html`, **sin** el prefijo `public/`. Prefiere nombres sin espacios ni tildes. Una URL HTTPS también funciona, pero depende del servidor de origen. Si una imagen falla en el navegador aparece un marcador local. Se puede ampliar cualquier foto con un clic.

## Publicación y datos internos

**Publica exclusivamente el contenido de `public/`.** Funciona en cualquier alojamiento estático compatible con HTML, CSS y JavaScript. No hay una publicación automática configurada. Si usas GitHub Pages u otro servicio, asegúrate de desplegar solo esa carpeta mediante el mecanismo del servicio.

No subas el ZIP completo, `datos/`, el Excel o el CSV con costes a una carpeta web pública. Si el repositorio de código es público, tampoco confirmes allí datos internos reales: mantenlos fuera del repositorio o en una ubicación privada. El servidor incluido sirve solo `public/` y no permite descargar la hoja de datos.

Que un valor no aparezca en pantalla no implica que sea secreto: el navegador necesita el **límite de inventario** para aplicar cantidades máximas, y este puede inspeccionarse en los datos públicos. Los códigos se transforman en identificadores hash estables para conservar la bolsa; no son una protección criptográfica de códigos fáciles de adivinar. Los costes no se exportan. Si en el futuro necesitas inventario confidencial o reserva real, hará falta un backend.

Al actualizar un alojamiento, publica `catalogo.js` y `catalogo.json` juntos. Si permite definir caché, evita caché prolongada para HTML y archivos del catálogo. No se incluye un service worker que retenga datos antiguos.

## Estructura

```text
public/                 Única carpeta que se publica
  index.html            Estructura y textos fijos
  styles.css            Diseño adaptable
  config.js             Marca, imágenes, WhatsApp y colores
  app.js                Búsqueda, categorías, bolsa y pedidos
  catalogo.js            Datos públicos para apertura directa
  catalogo.json          Datos públicos para refrescar por HTTP
  assets/               Logo, cabecera, trama e imágenes
 datos/
  productos.xlsx        Hoja de trabajo con ejemplos
  productos.csv         CSV con las mismas diez columnas
 tools/
  build.py              Valida y genera el catálogo
  serve.py              Servidor local restringido a public/
 tests/
  test_build.py         Pruebas de datos y conversión
  browser_smoke.py      Prueba funcional sin enviar WhatsApp
```

`catalogo.js` y `catalogo.json` son generados: no los edites a mano. No cambies `cod` de un producto existente si quieres conservar su referencia en las bolsas guardadas.

## Comprobaciones

Desde la raíz del proyecto:

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

La prueba de navegador es opcional y requiere Playwright y Chromium (las pruebas no son necesarias para usar el catálogo):

```sh
python3 -m pip install playwright
python3 -m playwright install chromium
python3 tools/serve.py --port 8010 --no-browser
# En otra terminal:
python3 tests/browser_smoke.py
```

Puedes indicar otra URL con la variable `AGORA_TEST_URL`. La prueba intercepta `window.open` para no visitar WhatsApp ni enviar mensajes; comprueba el texto generado. También prueba el catálogo, imágenes, filtros, búsqueda, moneda obligatoria, totales mixtos, inventario máximo, persistencia, actualización de existencias, modal, tamaño móvil y apertura directa. Genera capturas de revisión fuera de la carpeta pública.

## Ideas para futuras versiones

- Favoritos independientes de la bolsa.
- Orden por precio con selector de moneda, sin comparar CUP y USD directamente.
- Variantes de talla/color con inventario propio.
- Panel de administración y reserva de existencias en servidor.
- Historial de pedidos con estados y confirmación del vendedor.

No están implementadas ni incluidas como servicios externos. Esta versión ya incluye vista ampliada, búsqueda sin tildes, mensajes sin resultados, navegación por teclado, diseño móvil y conservación de bolsa.
