#!/usr/bin/env python3
"""Genera datos públicos desde CSV o Excel. Los costes y códigos no se publican."""
import argparse, csv, hashlib, io, json, math, os, sys, tempfile, zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
COLUMNS=['cod','prod','inv','descripc','categ','costocup','preciocup','costousd','preciousd','img']
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def read_excel(path):
    # Standard Excel workbook: first sheet is Productos; stored values, not formulas.
    with zipfile.ZipFile(path) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(t.text or '' for t in si.findall('.//m:t',NS)) for si in root]
        workbook=ET.fromstring(z.read('xl/workbook.xml'))
        sheet=next((s for s in workbook.findall('m:sheets/m:sheet',NS) if s.get('name')=='Productos'),None)
        if sheet is None:raise ValueError('El Excel debe tener una hoja llamada Productos.')
        relid=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target=next(r.get('Target') for r in rels if r.get('Id')==relid)
        filename=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        root=ET.fromstring(z.read(filename));rows=[]
        for row in root.findall('m:sheetData/m:row',NS):
            cells={}
            for cell in row:
                index=0
                for c in cell.get('r',''):
                    if c.isalpha():index=index*26+ord(c.upper())-64
                if cell.find('m:f',NS) is not None:raise ValueError(f'No se admiten fórmulas en Productos ({cell.get("r")}); pega valores.')
                value=cell.findtext('m:v',default='',namespaces=NS)
                if cell.get('t')=='s':value=strings[int(value)]
                elif cell.get('t')=='inlineStr':value=''.join(t.text or '' for t in cell.findall('.//m:t',NS))
                cells[index-1]=value
            rows.append([cells.get(i,'') for i in range(max(cells,default=-1)+1)])
        return rows

def read_rows(path):
    if path.suffix.lower()=='.xlsx': rows=read_excel(path)
    else:
        text=path.read_text(encoding='utf-8-sig')
        first=text.splitlines()[0] if text.strip() else ''
        delimiter=';' if first.count(';')>first.count(',') else ','
        rows=list(csv.reader(io.StringIO(text),delimiter=delimiter,strict=True))
    if not rows:raise ValueError('La tabla está vacía.')
    header=[str(v).strip().lower() for v in rows[0]]
    if len(header)!=len(set(header)) or set(header)!=set(COLUMNS):raise ValueError('Las columnas deben ser exactamente: '+', '.join(COLUMNS))
    result=[]
    for n,row in enumerate(rows[1:],2):
        if not any(str(v).strip() for v in row):continue
        if len(row)>len(header):raise ValueError(f'Fila {n}: hay más valores que columnas.')
        row=row+['']*(len(header)-len(row));result.append((n,{k:str(v).strip() for k,v in zip(header,row)}))
    return result

def price(value,row,column):
    if not value:return None
    try:
        number=Decimal(value.replace(',','.'))
        if not number.is_finite() or number<0 or number>Decimal('1000000000') or number.as_tuple().exponent < -2:raise ValueError()
        return int(number*100) if number else None
    except (InvalidOperation,ValueError):raise ValueError(f'Fila {row}: {column} debe ser un número positivo con hasta dos decimales, sin separadores de miles (o vacío).')

def compile_catalog(rows):
    products=[];seen=set()
    for n,r in rows:
        code=r['cod']
        if not code or code in seen:raise ValueError(f'Fila {n}: cod vacío o repetido.')
        seen.add(code)
        try:
            number=Decimal(r['inv']);stock=int(number)
            if not number.is_finite() or number!=stock or stock<0 or stock>1000000:raise ValueError()
        except (ValueError,InvalidOperation,OverflowError):raise ValueError(f'Fila {n}: inv debe ser un entero entre 0 y 1000000.')
        if not r['prod'] or not r['categ']:raise ValueError(f'Fila {n}: prod y categ son obligatorios.')
        prices={c:v for c,col in [('CUP','preciocup'),('USD','preciousd')] if (v:=price(r[col],n,col)) is not None}
        if not prices and stock>0:raise ValueError(f'Fila {n}: un producto disponible necesita al menos un precio mayor que cero.')
        if stock==0:continue
        image=r['img'] or 'assets/placeholder.svg'
        if ':' in image and not image.startswith(('https://','http://')):raise ValueError(f'Fila {n}: img debe ser una ruta local o URL HTTP/HTTPS.')
        if not image.startswith(('https://','http://')):
            imagepath=(ROOT/'public'/image).resolve()
            if not imagepath.is_relative_to((ROOT/'public').resolve()):raise ValueError(f'Fila {n}: imagen fuera de public.')
            if not imagepath.is_file():raise ValueError(f'Fila {n}: no existe la imagen {image}.')
        products.append({'id':hashlib.sha256(code.encode()).hexdigest()[:24],'name':r['prod'],'description':r['descripc'],'category':r['categ'],'prices':prices,'limit':stock,'image':image})
    return {'version':1,'products':products}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('source',nargs='?',type=Path,default=ROOT/'datos/productos.csv');args=parser.parse_args()
    try:
        rows=read_rows(args.source);data=compile_catalog(rows)
        payload=json.dumps(data,ensure_ascii=False,indent=2)
        outputs={'catalogo.json':payload+'\n','catalogo.js':'window.AGORA_DATA = '+payload.replace('<','\\u003c')+';\n'}
        if args.source.suffix.lower()=='.xlsx':
            buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=COLUMNS);writer.writeheader();writer.writerows(r for _,r in rows)
            (ROOT/'datos/productos.csv').write_text(buffer.getvalue(),encoding='utf-8-sig')
        for name,contents in outputs.items():
            target=ROOT/'public'/name
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=target.parent,delete=False) as f:f.write(contents);temp=f.name
            os.replace(temp,target)
        print(f'Catálogo generado: {len(data["products"])} productos disponibles. Costes y códigos excluidos de public/.')
    except (ValueError,OSError,zipfile.BadZipFile,ET.ParseError) as e:print(f'ERROR: {e}',file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())
