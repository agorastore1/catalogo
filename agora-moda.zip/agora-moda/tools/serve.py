#!/usr/bin/env python3
"""Sirve únicamente la carpeta pública; nunca la hoja con costes."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse, webbrowser
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8000);p.add_argument('--no-browser',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[1]/'public'
server=ThreadingHTTPServer(('127.0.0.1',a.port),partial(SimpleHTTPRequestHandler,directory=str(root)))
print(f'Àgora Moda: http://127.0.0.1:{a.port} (Ctrl+C para salir)',flush=True)
if not a.no_browser:webbrowser.open(f'http://127.0.0.1:{a.port}')
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()
