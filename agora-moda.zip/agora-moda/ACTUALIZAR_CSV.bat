@echo off
cd /d "%~dp0"
python tools\build.py datos\productos.csv
pause
