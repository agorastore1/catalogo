import importlib.util, unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('build',Path(__file__).resolve().parents[1]/'tools/build.py');build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
class CatalogTests(unittest.TestCase):
    def setUp(self):self.rows=build.read_rows(build.ROOT/'datos/productos.csv')
    def test_excel_csv_equivalent(self):self.assertEqual(build.compile_catalog(self.rows),build.compile_catalog(build.read_rows(build.ROOT/'datos/productos.xlsx')))
    def test_private_fields_and_empty_categories(self):
        data=build.compile_catalog(self.rows);self.assertEqual(len(data['products']),9)
        for p in data['products']:
            self.assertFalse({'cod','costocup','costousd'} & p.keys());self.assertNotEqual(p['category'],'Solo agotados')
            self.assertGreater(p['limit'],0)
    def test_duplicate_code_rejected(self):
        with self.assertRaises(ValueError):build.compile_catalog(self.rows+[self.rows[0]])
    def test_invalid_inventory_rejected(self):
        for value in ['-1','2.5','NaN','Infinity','texto']:
            row=dict(self.rows[0][1],inv=value)
            with self.subTest(value=value),self.assertRaises(ValueError):build.compile_catalog([(2,row)])
    def test_money(self):
        self.assertEqual(build.price('12,34',2,'preciocup'),1234)
        self.assertIsNone(build.price('0',2,'preciocup'))
        for value in ['NaN','-1','Infinity','1.001','1,000.00']:
            with self.subTest(value=value),self.assertRaises(ValueError):build.price(value,2,'preciocup')
    def test_no_price_rejected(self):
        with self.assertRaises(ValueError):build.compile_catalog([(2,dict(self.rows[0][1],preciocup='',preciousd=''))])
    def test_unsafe_image_rejected(self):
        for image in ['javascript:alert(1)','../datos/productos.csv']:
            with self.subTest(image=image),self.assertRaises(ValueError):build.compile_catalog([(2,dict(self.rows[0][1],img=image))])
if __name__=='__main__':unittest.main()
