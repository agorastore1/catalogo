"""Requiere Playwright y Chromium. No envía mensajes ni abre WhatsApp."""
import json, os
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.sync_api import sync_playwright,expect,Error
BASE=os.environ.get('AGORA_TEST_URL','http://127.0.0.1:8010')
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    options={'headless':True}
    if os.path.isfile('/usr/bin/chromium'):options.update(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    browser=p.chromium.launch(**options);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.add_init_script('window.open = (url) => { window.lastOpenedURL = url; return null; };')
    page.goto(BASE);expect(page.locator('.product')).to_have_count(9)
    expect(page.locator('.category')).to_have_count(7)
    assert 'Solo agotados' not in page.locator('#categories').inner_text()
    page.locator('.product-image img').evaluate_all('async imgs => { for (const i of imgs) { i.loading = \"eager\"; await i.decode(); } }')
    page.locator('#search').fill('icaró');expect(page.locator('.product')).to_have_count(1)
    page.locator('#clear-search').click();page.get_by_role('button',name='Vestidos 2',exact=True).click();expect(page.locator('.product')).to_have_count(2)
    page.locator('#search').fill('ninguno');expect(page.locator('#empty')).to_be_visible();page.locator('#reset-filters').click()
    card=page.locator('.product').filter(has=page.get_by_role('heading',name='Vestido Atenea',exact=True))
    card.locator('.add').click();expect(page.locator('#cart-count')).to_have_text('0')
    card.locator('select').select_option('USD');card.locator('.add').click();expect(page.locator('#cart-count')).to_have_text('1')
    cup=page.locator('.product').filter(has=page.get_by_role('heading',name='Tenis Calíope',exact=True));cup.locator('.add').click()
    page.reload();expect(page.locator('#cart-count')).to_have_text('2');page.locator('#open-cart').click()
    expect(page.locator('#total-usd')).to_have_text('5,00 USD');expect(page.locator('#total-cup')).to_have_text('3500,00 CUP')
    for _ in range(3):page.get_by_role('button',name='Aumentar cantidad de Vestido Atenea',exact=True).click()
    expect(page.get_by_role('button',name='Aumentar cantidad de Vestido Atenea',exact=True)).to_be_disabled()
    expect(page.locator('#total-usd')).to_have_text('20,00 USD')
    page.locator('#checkout').click();expect(page.locator('#order-link')).to_be_visible()
    url=page.evaluate('window.lastOpenedURL');assert url.startswith('https://wa.me/5358113140?text=')
    msg=parse_qs(urlparse(url).query)['text'][0];assert '4 × 5,00 USD = 20,00 USD' in msg and 'Total CUP: 3500,00 CUP' in msg
    assert 'DEMO-' not in msg;expect(page.locator('#cart-count')).to_have_text('5')
    # Checkout detects a changed published inventory before opening WhatsApp.
    data=json.loads((ROOT/'public/catalogo.json').read_text());data['products'][0]['limit']=1
    page.route('**/catalogo.json',lambda route:route.fulfill(json=data))
    page.evaluate('window.lastOpenedURL = null');page.locator('#checkout').click();expect(page.locator('#cart-count')).to_have_text('2');assert page.evaluate('window.lastOpenedURL') is None
    page.unroute('**/catalogo.json');page.locator('#close-cart').click()
    page.locator('.product-image').first.click();expect(page.locator('#image-dialog')).to_be_visible();page.keyboard.press('Escape');expect(page.locator('#image-dialog')).not_to_be_visible()
    page.locator('.product-image img').evaluate_all('async imgs => { for (const i of imgs) { i.loading = \"eager\"; await i.decode(); } }')
    page.locator('#toast').evaluate('(n)=>n.classList.remove(\"show\")')
    page.screenshot(path=str(ROOT.parent/'agora-desktop.png'),full_page=True)
    page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(ROOT.parent/'agora-mobile.png'),full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Mobile overflow'
    assert not errors,errors
    # Internal spreadsheet must not be served by the development server.
    assert page.request.get(BASE+'/datos/productos.xlsx').status==404
    # File mode: portable package opens without a server.
    try:
        page.goto((ROOT/'public/index.html').as_uri());expect(page.locator('.product')).to_have_count(9)
        print('PASS: file mode')
    except Error as e:
        if 'ERR_BLOCKED_BY_ADMINISTRATOR' not in str(e): raise
        print('SKIP: file mode blocked by managed browser policy; HTTP workflow verified.')
    print('PASS: catalog, 6 categories, images, search, filters, currency selection, mixed totals, stock cap, persisted cart, WhatsApp text, stock revalidation, image modal, mobile layout, private-data isolation. No message sent.')
    browser.close()
